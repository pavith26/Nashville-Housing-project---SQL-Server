-- -- 1) Show the Customers table.
-- select *
-- from Customers;


-- -- 2) What cities are the Customers from?
-- select distinct City
-- from Customers;


-- -- 3) Use count to determine if there are duplicate cities in the Customers table.
-- select count(*)
-- from Customers;


-- select count(distinct City)
-- from Customers;


-- -- 4) Display the name and address of all customers from Mexico.
-- select CustomerName, Address, Country
-- from Customers
-- where Country = 'Mexico';


-- -- 5) Display the postcodes of all customers who are from either Berlin or any city in Spain.
-- select PostalCode, City, Country
-- from Customers
-- where City = 'Berlin' or Country = 'Spain';


-- -- 6) The company has recently updated the terms and conditions for all countries except France. We need to write a letter to all customers except those in France. Your manager has asked you to write an SQL query to extract the relevant data from the database.
-- select CustomerName, ContactName, Address, City, PostalCode, Country
-- from Customers
-- where not Country = 'France';


-- -- 7) It's come to the attention of upper management that some older customers haven't provided their address information. You have been asked to provide a list of all such customers so that they can be contacted and asked to provide their address.
-- select *
-- from Customers
-- where Address is null;


-- -- 8) Display the first 3 customers in alphabetical order of their customer name. Hint: limit n can be used to limit the number of results, order by column_name asc|desc can be used to sort the results.
-- select *
-- from Customers
-- order by CustomerName asc
-- limit 3;


-- -- 9) What's the name of the customer who placed order 10383?
-- select CustomerName
-- from Customers
-- where CustomerID = (
--     select CustomerID
--     from Orders
--     where OrderID = 10383
-- );

-- select CustomerName
-- from Customers
-- inner join Orders on Customers.CustomerID = Orders.CustomerID
-- where OrderID = 10383;


-- -- 10) Challenge question: Orders made in 1997 where either the order was made by a customer from the USA/Brazil OR the product ordered was supplied by a supplier based in the USA/Brazil, but not including those orders shipped by Federal Shipping.
-- select *
-- from Orders
-- inner join Customers on Customers.CustomerID = Orders.CustomerID
-- inner join OrderDetails on Orders.OrderID = OrderDetails.OrderID
-- inner join Products on OrderDetails.ProductID = Products.ProductID
-- inner join Suppliers on Products.SupplierID = Suppliers.SupplierID
-- inner join Shippers on Orders.ShipperID = Shippers.ShipperID
-- where strftime('%Y', Orders.OrderDate) = '1997' and Shippers.ShipperName != 'Federal Shipping' and (
--     (Customers.Country = 'USA' or Customers.Country = 'Brazil') or
--     (Suppliers.Country = 'USA' or Suppliers.Country = 'Brazil')
-- );


-- -- 11) Display a count of how many customers there are in total
-- select count(*)
-- from Customers;


-- -- 12) Display a count of how many customers there are in Germany
-- select count(*)
-- from Customers
-- where Country = 'Germany';


-- -- 13) Display a count of how many customers are in each country (using GROUP BY)
-- select count(*), Country
-- from Customers
-- group by Country;


-- -- 14) Display how many customers are in each country ordered such that the country with the largest number of customers comes first
-- select count(*), Country
-- from Customers
-- group by Country
-- order by -count(*);


-- -- 15) We know that every customer has 10 potential referrals. Display a count of how many potential referrals are in each country.
-- select count(*)*10, Country
-- from Customers
-- group by Country;


-- -- 16) We know how many customers there are in total from question 4). Use this value within a query to calculate the percentage of customers that come from Argentina.
-- select count(*)*100/92
-- from Customers
-- where Country = 'Argentina';


-- 17) Similarly, calculate the percentage of customers that come from each country.


-- 18) Answer question 17 again without using any hard-coded values.


-- 19) Homework challenge: Show a percentage of how many orders were made by each shipper.